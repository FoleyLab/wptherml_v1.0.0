#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
initializer for the wptherml package
"""
name = "example_pkg"
